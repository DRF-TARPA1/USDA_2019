CREATE OR REPLACE FUNCTION fs_fiadb.STDSZCDlabel(
	stdszcd integer)
    RETURNS text as $$
DECLARE
STDSZCDlabel varchar(64);
BEGIN
if stdszcd=1 then
stdszcdlabel :='`0001 Large diameter';
elsif stdszcd=2 then stdszcdlabel:='`0002 Medium diameter';
elsif stdszcd=3 then stdszcdlabel:='`0003 Small diameter';
elsif stdszcd=5 then stdszcdlabel:='`0004 Nonstocked';
else stdszcdlabel:='`0005 Other';
end if;
     RETURN STDSZCDlabel ;
END;
$$ LANGUAGE plpgsql;