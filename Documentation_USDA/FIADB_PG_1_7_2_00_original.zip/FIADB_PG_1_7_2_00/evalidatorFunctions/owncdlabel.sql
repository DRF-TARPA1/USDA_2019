CREATE OR REPLACE FUNCTION fs_fiadb.OWNCDlabel(owncd INTEGER)
  RETURNS TEXT AS $$
DECLARE
owncdlabel varchar(64);
BEGIN
if    owncd=11 then owncdlabel:='`0001 National Forest';
elsif owncd=12 then owncdlabel:='`0001 National Forest';
elsif owncd=13 then owncdlabel:='`0001 National Forest';
elsif owncd=21 then owncdlabel:='`0002 National Park Service';
elsif owncd=22 then owncdlabel:='`0003 Bureau of Land Mgmt';
elsif owncd=23 then owncdlabel:='`0004 Fish and Wildlife Service';
elsif owncd=24 then owncdlabel:='`0005 Dept of Defense';
elsif owncd=25 then owncdlabel:='`0006 Other federal';
elsif owncd=31 then owncdlabel:='`0007 State';
elsif owncd=32 then owncdlabel:='`0008 County and Municipal';
elsif owncd=33 then owncdlabel:='`0009 Other local govt';
elsif owncd=41 then owncdlabel:='`0010 Private';
elsif owncd=42 then owncdlabel:='`0011 Private';
elsif owncd=43 then owncdlabel:='`0012 Private';
elsif owncd=44 then owncdlabel:='`0013 Private';
elsif owncd=45 then owncdlabel:='`0014 Private';
elsif owncd=46 then owncdlabel:='`0015 Private';
else owncdlabel:='`0016 Other';
end if;
     RETURN owncdlabel ;
END;
$$ LANGUAGE plpgsql;
