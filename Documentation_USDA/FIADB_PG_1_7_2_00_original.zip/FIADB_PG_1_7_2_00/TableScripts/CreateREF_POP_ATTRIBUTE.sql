-- Create table
create table FS_FIADB.REF_POP_ATTRIBUTE
(
  cn                   VARCHAR(34) not null,
  attribute_nbr        SMALLINT not null,
  attribute_descr      VARCHAR(255),
  timberland           VARCHAR(1),
  eval_typ             VARCHAR(15),
  expression           VARCHAR(4000),
  where_clause         VARCHAR(4000),
  footnote             VARCHAR(2000),
  attribute_glossary   VARCHAR(4000),
  created_by           VARCHAR(30),
  created_date         TIMESTAMP(0),
  created_in_instance  VARCHAR(6),
  modified_by          VARCHAR(30),
  modified_date        TIMESTAMP(0),
  modified_in_instance VARCHAR(6),
  notes                VARCHAR(2000),
  sql_query            VARCHAR(4000)
);
-- Add comments to the table 
comment on table FS_FIADB.REF_POP_ATTRIBUTE
  is '6.0';
-- Add comments to the columns 
comment on column FS_FIADB.REF_POP_ATTRIBUTE.cn
  is 'Sequence number (surrogate primary key';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.attribute_nbr
  is 'Arbitrary unique number';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.attribute_descr
  is 'Estimation attribute e.g. Area of timberland';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.timberland
  is 'Y if the attribute is computed only on the timberland domain. N if the attribute is computed on the forest land domain.';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.eval_typ
  is 'The evaluation type associated with the attribute. It is assumed that an attribute can only be associated with on evaluation type.';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.expression
  is 'Part of the expression used to produce the estimate';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.where_clause
  is 'Part of the where clause (does not include filter e.g. p.statecd = 27)';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.footnote
  is 'Contains footnote to be used in reports summarizing the attribute.';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.created_by
  is 'Created by';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.created_date
  is 'Created Date';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.created_in_instance
  is 'Created in Instance';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.modified_by
  is 'Modified by';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.modified_date
  is 'Modified Date';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.modified_in_instance
  is 'Modified in Instance';
comment on column FS_FIADB.REF_POP_ATTRIBUTE.notes
  is 'Notes';
-- Create/Recreate primary, unique and foreign key constraints 
alter table FS_FIADB.REF_POP_ATTRIBUTE
  add constraint PAE_PK primary key (CN);
alter table FS_FIADB.REF_POP_ATTRIBUTE
  add constraint PAE_UK unique (ATTRIBUTE_NBR);