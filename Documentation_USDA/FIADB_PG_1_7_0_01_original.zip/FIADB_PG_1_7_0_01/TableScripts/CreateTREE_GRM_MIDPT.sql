-- Create table
create table FS_FIADB.TREE_GRM_MIDPT
(
  tre_cn               VARCHAR(34) not null,
  prev_tre_cn          VARCHAR(34),
  plt_cn               VARCHAR(34) not null,
  statecd              SMALLINT not null,
  dia                  DOUBLE PRECISION not null,
  diahtcd              SMALLINT not null,
  tree_size            VARCHAR(10),
  treeclcd             SMALLINT,
  subptyp              DOUBLE PRECISION,
  volcfsnd             DOUBLE PRECISION,
  volcfnet             DOUBLE PRECISION,
  volcsnet             DOUBLE PRECISION,
  volbfnet             DOUBLE PRECISION,
  regional_drybiot     DOUBLE PRECISION,
  regional_drybiom     DOUBLE PRECISION,
  regional_drybiosl    DOUBLE PRECISION,
  drybio_bg            DOUBLE PRECISION,
  drybio_ag            DOUBLE PRECISION,
  drybio_wdld_spp      DOUBLE PRECISION,
  drybio_sapling       DOUBLE PRECISION,
  drybio_stump         DOUBLE PRECISION,
  drybio_bole          DOUBLE PRECISION,
  drybio_sawlog        DOUBLE PRECISION,
  drybio_top           DOUBLE PRECISION,
  created_by           VARCHAR(30),
  created_date         TIMESTAMP(0),
  created_in_instance  VARCHAR(6),
  modified_by          VARCHAR(30),
  modified_date        TIMESTAMP(0),
  modified_in_instance VARCHAR(6)
);
-- Add comments to the columns 
comment on column FS_FIADB.TREE_GRM_MIDPT.tre_cn
  is 'Foreign key to TREE table CN';
comment on column FS_FIADB.TREE_GRM_MIDPT.prev_tre_cn
  is 'Foreign key to time 1 tree CN';
comment on column FS_FIADB.TREE_GRM_MIDPT.plt_cn
  is 'Foreign key to NIMS_PLOT_TBL CN';
comment on column FS_FIADB.TREE_GRM_MIDPT.statecd
  is 'State Code';
comment on column FS_FIADB.TREE_GRM_MIDPT.dia
  is 'Diameter';
comment on column FS_FIADB.TREE_GRM_MIDPT.diahtcd
  is 'Height of diameter measurement code';
comment on column FS_FIADB.TREE_GRM_MIDPT.tree_size
  is 'Tree size';
comment on column FS_FIADB.TREE_GRM_MIDPT.treeclcd
  is 'Tree class code';
comment on column FS_FIADB.TREE_GRM_MIDPT.subptyp
  is 'Subplot type code';
comment on column FS_FIADB.TREE_GRM_MIDPT.volcfsnd
  is 'Sound cubic-foot volume';
comment on column FS_FIADB.TREE_GRM_MIDPT.volcfnet
  is 'Net cubic-foot volume';
comment on column FS_FIADB.TREE_GRM_MIDPT.volcsnet
  is 'Net cubic-foot volume in the saw-log portion';
comment on column FS_FIADB.TREE_GRM_MIDPT.volbfnet
  is 'Net board-foot volume in the saw-log portion';
comment on column FS_FIADB.TREE_GRM_MIDPT.regional_drybiot
  is 'Total gross biomass ovendry weight';
comment on column FS_FIADB.TREE_GRM_MIDPT.regional_drybiom
  is 'Merchantable stem biomass ovendry weight';
comment on column FS_FIADB.TREE_GRM_MIDPT.regional_drybiosl
  is 'Sawlog biomass ovendry weight';
comment on column FS_FIADB.TREE_GRM_MIDPT.drybio_bg
  is 'Below ground dry biomass (pounds)';
comment on column FS_FIADB.TREE_GRM_MIDPT.drybio_ag
  is 'Above ground dry biomass (pounds)';
comment on column FS_FIADB.TREE_GRM_MIDPT.drybio_wdld_spp
  is 'Dry biomass aboveground in woodland species trees (pounds)';
comment on column FS_FIADB.TREE_GRM_MIDPT.drybio_sapling
  is 'Dry biomass aboveground in trees 1 to 4.9 inches in diameter (pounds)';
comment on column FS_FIADB.TREE_GRM_MIDPT.drybio_stump
  is 'Dry biomass in the stump of trees 5 inches or larger in diameter (pounds)';
comment on column FS_FIADB.TREE_GRM_MIDPT.drybio_bole
  is 'Dry biomass in the bole of trees 5 inches or larger in diameter (pounds)';
comment on column FS_FIADB.TREE_GRM_MIDPT.drybio_sawlog
  is 'Dry biomass in the sawlog portion (pounds)';
comment on column FS_FIADB.TREE_GRM_MIDPT.drybio_top
  is 'Dry biomass in the top and limbs of trees 5 inches or larger in diameter (pounds)';
comment on column FS_FIADB.TREE_GRM_MIDPT.created_by
  is 'Created by';
comment on column FS_FIADB.TREE_GRM_MIDPT.created_date
  is 'Created Date';
comment on column FS_FIADB.TREE_GRM_MIDPT.created_in_instance
  is 'Created in Instance';
comment on column FS_FIADB.TREE_GRM_MIDPT.modified_by
  is 'Modified by';
comment on column FS_FIADB.TREE_GRM_MIDPT.modified_date
  is 'Modified Date';
comment on column FS_FIADB.TREE_GRM_MIDPT.modified_in_instance
  is 'Modified in Instance';
-- Create/Recreate indexes 
create index TRE_GRM_MIDPT_IND1 on FS_FIADB.TREE_GRM_MIDPT (PLT_CN);
create index TRE_GRM_MIDPT_IND2 on FS_FIADB.TREE_GRM_MIDPT (PREV_TRE_CN);
create index TRE_GRM_MIDPT_IND3 on FS_FIADB.TREE_GRM_MIDPT (STATECD);
-- Create/Recreate primary, unique and foreign key constraints 
alter table FS_FIADB.TREE_GRM_MIDPT
  add constraint TRE_GRM_MIDPT_PK primary key (TRE_CN);
alter table FS_FIADB.TREE_GRM_MIDPT
  add constraint TRE_GRM_MIDPT_FK foreign key (TRE_CN)
  references FS_FIADB.TREE (CN);