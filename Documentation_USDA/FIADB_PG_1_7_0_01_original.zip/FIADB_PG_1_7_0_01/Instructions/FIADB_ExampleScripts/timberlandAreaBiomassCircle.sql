-- The contents of this file (timberlandAreaBiomassCircle.sql) can be run from the pgAdmin Query Tool to produce
-- six estimates of timberland acres and live tree biomass.
-- 1) The table "fs_fiadb.circleLocations" is created and six records are loaded into the table.
-- 2) The "fs_fiadb.timberlandacres" function is created in the Postgres testdb database.
-- 3) The "fs_fiadb.timberlandbiomass" function is created in the Postgres testdb database.
-- 4) a select query is run that queries the "fs_fiadb.circlelocations" table and runs the two functions
--    returning estimates of acres and biomass for each of the six records in "fs_fiadb.circlelocations".

--drop TABLE fs_fiadb.outtabletimberlandacres;
CREATE TABLE fs_fiadb.outtabletimberlandacres(sql_text text);
drop table fs_fiadb.circleLocations;
CREATE TABLE fs_fiadb.circleLocations(id integer, lat text, lon text, radius text, evalgrps text);
INSERT INTO fs_fiadb.circleLocations VALUES (1,'39.0','-93.0','50.0','292016,052015');
INSERT INTO fs_fiadb.circleLocations VALUES (2,'39.1','-93.0','50.0','292016,052015');
INSERT INTO fs_fiadb.circleLocations VALUES (3,'39.2','-93.0','50.0','292016,052015');
INSERT INTO fs_fiadb.circleLocations VALUES (4,'39.0','-93.0','100.0','292016,052015');
INSERT INTO fs_fiadb.circleLocations VALUES (5,'39.1','-93.0','100.0','292016,052015');
INSERT INTO fs_fiadb.circleLocations VALUES (6,'39.2','-93.0','100.0','292016,052015');



CREATE OR REPLACE FUNCTION fs_fiadb.timberlandacres(a text,b text,c text, d text) 
RETURNS double precision AS $body$
DECLARE r double precision;
q text;
sql_text text;
BEGIN
q='''';
sql_text:= 'SELECT SUM(coalesce(psm.expns,0) * c.condprop_unadj * CASE c.PROP_BASIS                      ';
sql_text:= sql_text || '             WHEN ' || q || 'MACR' || q || ' THEN                                ';
sql_text:= sql_text || '              coalesce(psm.ADJ_FACTOR_MACR,0)                                    ';
sql_text:= sql_text || '             ELSE                                                                ';
sql_text:= sql_text || '              coalesce(psm.ADJ_FACTOR_SUBP,0)                                    ';
sql_text:= sql_text || '           END)                                                                  ';
sql_text:= sql_text || '  FROM fs_fiadb.pop_eval_grp peg                                                 ';
sql_text:= sql_text || '  join fs_fiadb.pop_eval_typ pet                                                 ';
sql_text:= sql_text || '    on (pet.eval_grp_cn = peg.cn)                                                ';
sql_text:= sql_text || '  join fs_fiadb.pop_eval pev                                                     ';
sql_text:= sql_text || '    on (pev.cn = pet.eval_cn)                                                    ';
sql_text:= sql_text || '  join fs_fiadb.pop_estn_unit peu                                                ';
sql_text:= sql_text || '    on (pev.cn = peu.eval_cn)                                                    ';
sql_text:= sql_text || '  join fs_fiadb.pop_stratum psm                                                  ';
sql_text:= sql_text || '    on (peu.cn = psm.estn_unit_cn)                                               ';
sql_text:= sql_text || '  join fs_fiadb.pop_plot_stratum_assgn ppsa                                      ';
sql_text:= sql_text || '    on (ppsa.stratum_cn = psm.cn)                                                ';
sql_text:= sql_text || '  join fs_fiadb.plot p                                                           ';
sql_text:= sql_text || '    on (ppsa.plt_cn = p.cn)                                                      ';
sql_text:= sql_text || '  join fs_fiadb.cond c                                                           ';
sql_text:= sql_text || '    on (p.cn = c.plt_cn)                                                         ';
sql_text:= sql_text || ' WHERE pet.eval_typ = ' || q || 'EXPCURR' || q || '                              ';
sql_text:= sql_text || '   AND c.cond_status_cd = 1                                                      ';
sql_text:= sql_text || '   AND c.reservcd = 0                                                            ';
sql_text:= sql_text || '   AND c.siteclcd IN (1, 2, 3, 4, 5, 6)                                          ';
sql_text:= sql_text || '   AND peg.eval_grp IN (' || d || ')                                          ';
sql_text:= sql_text || '   and ST_Distance(ST_GeogFromText(' || q || 'SRID=4269;POINT(' ||b ||' '|| a ||')' || q || '),                  ';
sql_text:= sql_text || '                   ST_GeogFromText(' || q || 'SRID=4269;POINT(' || q || ' ||                       ';
sql_text:= sql_text || '                                   to_char(p.lon, ' || q || '9999.9999999' || q || ') || ' || q || ' ' || q || ' ||  ';
sql_text:= sql_text || '                                   to_char(p.lat, ' || q || '9999.9999999' || q || ') || ' || q || ')' || q || ' ||  ';
sql_text:= sql_text || '                                   ' || q || q || q || '||' || q || ')) < 1609.344 * '||c;  
insert into fs_fiadb.outtabletimberlandacres values(sql_text);
execute sql_text into r;
  RETURN r;
END;
$body$ LANGUAGE plpgsql;




--drop TABLE fs_fiadb.outtabletimberlandbiomass;
CREATE TABLE fs_fiadb.outtabletimberlandbiomass(sql_text text);
CREATE OR REPLACE FUNCTION fs_fiadb.timberlandbiomass(a text,b text,c text, d text)                                 
RETURNS double precision AS $body$
DECLARE r double precision;
q text;
sql_text text;
BEGIN
q='''';
sql_text:= 'SELECT SUM(psm.expns * COALESCE(t.TPA_UNADJ * coalesce(t.drybio_bole,0) * CASE                              ';
sql_text:= sql_text || '      WHEN t.DIA IS NULL THEN                                                    ';
sql_text:= sql_text || '       psm.ADJ_FACTOR_SUBP                                                       ';
sql_text:= sql_text || '      ELSE                                                                       ';
sql_text:= sql_text || '       CASE LEAST(t.DIA, 5 - 0.001)                                              ';
sql_text:= sql_text || '         WHEN t.DIA THEN                                                         ';
sql_text:= sql_text || '          psm.ADJ_FACTOR_MICR                                                    ';
sql_text:= sql_text || '         ELSE                                                                    ';
sql_text:= sql_text || '          CASE LEAST(t.DIA, COALESCE(p.MACRO_BREAKPOINT_DIA, 9999) - 0.001)      ';
sql_text:= sql_text || '            WHEN t.DIA THEN                                                      ';
sql_text:= sql_text || '             psm.ADJ_FACTOR_SUBP                                                 ';
sql_text:= sql_text || '            ELSE                                                                 ';
sql_text:= sql_text || '             psm.ADJ_FACTOR_MACR                                                 ';
sql_text:= sql_text || '          END                                                                    ';
sql_text:= sql_text || '       END                                                                       ';
sql_text:= sql_text || '    END,                                                                         ';
sql_text:= sql_text || '    0))/2000.0                                                                          '; 
sql_text:= sql_text || '  FROM fs_fiadb.pop_eval_grp peg                                                 ';
sql_text:= sql_text || '  join fs_fiadb.pop_eval_typ pet                                                 ';
sql_text:= sql_text || '    on (pet.eval_grp_cn = peg.cn)                                                ';
sql_text:= sql_text || '  join fs_fiadb.pop_eval pev                                                     ';
sql_text:= sql_text || '    on (pev.cn = pet.eval_cn)                                                    ';
sql_text:= sql_text || '  join fs_fiadb.pop_estn_unit peu                                                ';
sql_text:= sql_text || '    on (pev.cn = peu.eval_cn)                                                    ';
sql_text:= sql_text || '  join fs_fiadb.pop_stratum psm                                                  ';
sql_text:= sql_text || '    on (peu.cn = psm.estn_unit_cn)                                               ';
sql_text:= sql_text || '  join fs_fiadb.pop_plot_stratum_assgn ppsa                                      ';
sql_text:= sql_text || '    on (ppsa.stratum_cn = psm.cn)                                                ';
sql_text:= sql_text || '  join fs_fiadb.plot p                                                           ';
sql_text:= sql_text || '    on (ppsa.plt_cn = p.cn)                                                      ';
sql_text:= sql_text || '  join fs_fiadb.cond c                                                           ';
sql_text:= sql_text || '    on (p.cn = c.plt_cn)                                                         ';
sql_text:= sql_text || '  join fs_fiadb.tree t                                                           ';
sql_text:= sql_text || '    on (c.plt_cn = t.plt_cn and c.condid = t.condid)                             ';
sql_text:= sql_text || ' WHERE pet.eval_typ = ' || q || 'EXPVOL' || q || '                               ';
sql_text:= sql_text || '   AND c.cond_status_cd = 1                                                      ';
sql_text:= sql_text || '   AND c.reservcd = 0                                                            ';
sql_text:= sql_text || '   AND c.siteclcd IN (1, 2, 3, 4, 5, 6)  AND t.statuscd = 1    '                 ;
sql_text:= sql_text || '   AND peg.eval_grp IN (' || d || ')                                                  ';
sql_text:= sql_text || '   and ST_Distance(ST_GeogFromText(' || q || 'SRID=4269;POINT(' ||b ||' '|| a ||')' || q || '),                  ';
sql_text:= sql_text || '                   ST_GeogFromText(' || q || 'SRID=4269;POINT(' || q || ' ||                       ';
sql_text:= sql_text || '                                   to_char(p.lon, ' || q || '9999.9999999' || q || ') || ' || q || ' ' || q || ' ||  ';
sql_text:= sql_text || '                                   to_char(p.lat, ' || q || '9999.9999999' || q || ') || ' || q || ')' || q || ' ||  ';
sql_text:= sql_text || '                                   ' || q || q || q || '||' || q || ')) < 1609.344 * '||c;  
insert into fs_fiadb.outtabletimberlandbiomass values(sql_text);
execute sql_text into r;
  RETURN r;
END;
$body$ LANGUAGE plpgsql;



select id,lat,lon,radius,evalgrps,fs_fiadb.timberlandacres(lat,lon,radius,evalgrps),fs_fiadb.timberlandbiomass(lat,lon,radius,evalgrps) from  fs_fiadb.circleLocations ;


--select * from fs_fiadb.outtabletimberlandacres;
--select * from fs_fiadb.outtabletimberlandbiomass;
